Grid-performance

*  Run the application
*  click renderGrid button and destroyGrid button


