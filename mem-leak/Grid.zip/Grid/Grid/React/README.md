# grid_Performance sample

> 

## Build Setup

``` bash
# install dependencies
npm install

# run the application
npm start

```
*  Run the application
*  click renderGrid button and destroyGrid button


