﻿using System;
using System.Collections.Generic;

namespace OdataApplication.Models;

public partial class OutLook
{
    public int? OutId { get; set; }

    public string? Sender { get; set; }

    public string? Subject { get; set; }

    public string? ReadStatus { get; set; }

    public string? Attachements { get; set; }

    public string? ContentsPath { get; set; }

    public string? Importance { get; set; }

    public DateTime? Received { get; set; }
}
