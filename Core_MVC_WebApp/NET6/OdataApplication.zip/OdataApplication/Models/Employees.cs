﻿using System.ComponentModel.DataAnnotations;

namespace OdataApplication.Models
{
    public class Employees
    {
        public static List<Employees> emp = new List<Employees>();
        public Employees()
        {

        }
        public Employees(int EmployeeID, string FirstName, string LastName)
        {
            this.EmployeeID = EmployeeID;
            this.FirstName = FirstName;
            this.LastName = LastName;
        }

        public static List<Employees> ForeignData()
        {
            if (emp.Count == 0)
            {
                int code = 10000;
                for (int i = 0; i < 1; i++)
                {
                    emp.Add(new Employees(code + 0, "Value" + "Berlin", @"""Andrew""" + i));
                    emp.Add(new Employees(code + 2, "valu2'", @"""Nancy""" + i));
                    emp.Add(new Employees(code + 1, @"""value3""", @"""Jarget""" + i));
                    emp.Add(new Employees(code + 3, @"""value4""", @"""Margrey""" + i));
                    emp.Add(new Employees(code + 4, @"""value5""", @"""doublequotes""" + i));
                    code += 5;
                }
            }
            return emp;
        }

        [Key]
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
