﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace OdataApplication.Models
{
    public class OrdersDetails
    {
        public OrdersDetails() { }
        public static List<OrdersDetails> order = new List<OrdersDetails>();
        public OrdersDetails(long OrderID, string CustomerID, int EmployeeID, decimal Freight, DateTime? OrderDate, string ShipCity, string ID)
        {
            this.OrderID = OrderID;
            this.CustomerID = CustomerID;
            this.EmployeeID = EmployeeID;
            this.Freight = Freight;
            this.OrderDate = OrderDate;
            this.ShipCity = ShipCity;
            this.Id = ID;
        }
        
        public static List<OrdersDetails> GetAllRecords()
        {
            if (order.Count == 0)
            {
                int code = 10000;
                for (int i = 0; i < 1; i++)
                {
                    order.Add(new OrdersDetails(code + 1, "%ALFKI", code + 0, 10.15m, new DateTime(1991, 05, 15), "Berlin", @"""Andrew""" + i));
                    order.Add(new OrdersDetails(code + 2, "ANATR%", code + 2, 12.12m, new DateTime(1990, 04, 04), "Madrid", @"""Nancy""" + i));
                    order.Add(new OrdersDetails(code + 3, "", code + 1, 11.9m, new DateTime(1957, 11, 30), "Cholchester", @"""Jarget""" + i));// ANTON
                    order.Add(new OrdersDetails(code + 4, "BLO%NP", code + 3, 9.6m, new DateTime(1930, 10, 22), "Marseille", @"""Margrey""" + i));
                    order.Add(new OrdersDetails(code + 5, "BOLID", code + 4, 6.3m, new DateTime(1953, 02, 18), "Tsawassen", @"""doublequotes""" + i));
                    code += 5;
                }
            }
            return order;
        }

        [Key]
        public long OrderID { get; set; }
        public string? CustomerID { get; set; }
        public int? EmployeeID { get; set; }
        public decimal Freight { get; set; }
        public DateTime? OrderDate { get; set; }
        public string ShipCity { get; set; }

        public string Id { get; set; }
    }
}