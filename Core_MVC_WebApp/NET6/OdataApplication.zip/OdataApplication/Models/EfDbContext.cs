﻿using Microsoft.EntityFrameworkCore;
using OdataApplication.Models;

namespace OdataApplication
{
    public class EfDbContext : DbContext
    {
        ////protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        ////{
        ////    string directory = Directory.GetCurrentDirectory();
        ////    string dir = "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=True";
        ////    optionsBuilder.UseNpgsql(dir);
        ////}
        public EfDbContext(DbContextOptions options) : base(options)
        {
        }

        //public virtual DbSet<CustomersDB> CustomerCustomerDemo { get; set; }
        public virtual DbSet<Shipper> Shippers { get; set; }

        public virtual DbSet<Order> Orders { get; set; }
    }
}
