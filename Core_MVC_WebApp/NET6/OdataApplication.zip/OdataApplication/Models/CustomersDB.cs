﻿using System.ComponentModel.DataAnnotations;

namespace OdataApplication.Models
{
    public class CustomersDB
    {
        [Key]
        public string customerID { get; set; }
        public string? customerTypeID { get; set; }
        //public string contactName { get; set; }
        //public string companyName { get; set; }
        //public string country { get; set; }
        //public string address { get; set; }
    }
}
