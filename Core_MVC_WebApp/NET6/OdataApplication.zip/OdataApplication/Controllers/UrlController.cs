﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OdataApplication.Models;
using Syncfusion.EJ2.Base;
using System.Diagnostics;

namespace OdataApplication.Controllers
{
    public class UrlController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly NorthwindContext _context;

        public UrlController(ILogger<HomeController> logger,
            NorthwindContext context)
        {
            _logger = logger;
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        [Route("Grid/UrlDataSource")]

        public IActionResult UrlDatasource([FromBody] DataManagerRequest dm)
        {
            // DB

            //Queryable
            IQueryable<Order> DataSource = _context.Orders.AsQueryable();
            QueryableOperation operation = new QueryableOperation();

            // Enumerable

            //IEnumerable<Order> DataSource = _context.Orders.AsEnumerable();
            //DataOperations operation = new DataOperations();

            // Local Data

            //Queryable
            //IQueryable<OrdersDetails> DataSource = OrdersDetails.GetAllRecords().AsQueryable();
            //QueryableOperation operation = new QueryableOperation();

            // Enumerable

            //IEnumerable<OrdersDetails> DataSource = OrdersDetails.GetAllRecords().AsEnumerable();
            //DataOperations operation = new DataOperations();
            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            //int count = DataSource.Cast<OrdersDetails>().Count();
            int count = DataSource.Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        [Route("Grid/FUrlDataSource")]
        public IActionResult FUrlDataSource([FromBody] DataManagerRequest dm)
        {
            // DB Data

            //Queryable

            IQueryable<Shipper> DataSource = _context.Shippers.AsQueryable();
            var operation = new QueryableOperation();

            // Enumerable

            //IEnumerable<Shipper> DataSource = _context.Shippers.AsEnumerable();
            //DataOperations operation = new DataOperations();

            // Local Data

            //Queryable

            //IQueryable<Employees> DataSource = Employees.ForeignData().AsQueryable();
            //var operation = new QueryableOperation();

            // Enumerable

            //IEnumerable<Employees> DataSource = Employees.ForeignData().AsEnumerable();
            //DataOperations operation = new DataOperations();

            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            if (dm.Search != null && dm.Search.Count > 0)  //Search
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }

            //if (dm.RequiresCounts)
            //{
            //    count = DataSource.Cast<OrdersDetails>().Count();
            //}

            //int count = DataSource.Cast<Employees>().Count();
            int count = DataSource.Count();

            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);//Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }
    }
}
