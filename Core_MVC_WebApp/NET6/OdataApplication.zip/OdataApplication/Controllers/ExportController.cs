﻿using Microsoft.AspNetCore.Mvc;
using OdataApplication.Models;
using Syncfusion.EJ2.GridExport;
using Syncfusion.EJ2.Grids;

namespace OdataApplication.Controllers
{
    public class ExportController : Controller
    {

        public IActionResult Index()
        {
            ViewBag.DataSource = OrdersDetails.GetAllRecords();
            return View();
        }

        public ActionResult ExcelExport([FromForm] string gridModel)
        {
            GridExcelExport exp = new GridExcelExport();
            Grid gridProperty = ConvertGridObject(gridModel);
            return exp.ExcelExport<OrdersDetails>(gridProperty, OrdersDetails.order);
        }

        private Grid ConvertGridObject(string gridProperty)
        {
            Grid GridModel = (Grid)Newtonsoft.Json.JsonConvert.DeserializeObject(gridProperty, typeof(Grid));
            GridColumnModel cols = (GridColumnModel)Newtonsoft.Json.JsonConvert.DeserializeObject(gridProperty, typeof(GridColumnModel));
            GridModel.Columns = cols.columns;
            return GridModel;
        }

        public class GridColumnModel
        {
            public List<GridColumn> columns { get; set; }
        }
    }
}
