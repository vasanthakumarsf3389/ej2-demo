﻿//using System.Collections.Generic;
//using System.Web.Mvc;
////using Syncfusion.EJ2.Grids;
//using Syncfusion.EJ2.Grids;
//using System;
//using Syncfusion.EJ2.GridExport;
//using GridExportMVC.Models;
//using System.Data;
//using System.Linq;
//using System.Collections;
//using Syncfusion.EJ2.Base;
//using System.Dynamic;

//namespace GridExportMVC.Controllers
//{
//    public class HomeController : Controller
//    {
//        public ActionResult Index()
//        {
//            var order = OrdersDetails.GetAllRecords();
//            ViewBag.datasource = order;
//            return View();
//        }
//        public ActionResult ExcelExport(string gridModel)
//        {
//            GridExcelExport exp = new GridExcelExport();
//            Grid gridProperty = ConvertGridObject(gridModel);
//            return exp.ExcelExport<OrdersDetails>(gridProperty, OrdersDetails.GetAllRecords());
//        }


//        public ActionResult PdfExport(string gridModel)
//        {
//            GridPdfExport exp = new GridPdfExport();
//            Grid gridProperty = ConvertGridObject(gridModel);
//            return exp.PdfExport<OrdersDetails>(gridProperty, OrdersDetails.GetAllRecords());
//        }
//        private Grid ConvertGridObject(string gridProperty)
//        {
//            Grid GridModel = (Grid)Newtonsoft.Json.JsonConvert.DeserializeObject(gridProperty, typeof(Grid));
//            GridColumnModel cols = (GridColumnModel)Newtonsoft.Json.JsonConvert.DeserializeObject(gridProperty, typeof(GridColumnModel));
//            GridModel.Columns = cols.columns;
//            return GridModel;
//        }
//        public class GridColumnModel
//        {
//            public List<GridColumn> columns { get; set; }
//        }
//    }
//}


//Export Feature


using System.Collections.Generic;
using System.Web.Mvc;
using Syncfusion.EJ2.Grids;
using System;
using System.Data;
using System.Linq;
using System.Collections;
using Syncfusion.EJ2.Base;
using Syncfusion.Pdf.Graphics;
using System.Drawing;
using Syncfusion.Pdf.Grid;
using Syncfusion.EJ2.GridExport;
using Syncfusion.XlsIO;

namespace GridExportMVC.Controllers
{
    public class HomeController : Controller
    {
        public static DataTable dt = new System.Data.DataTable("Table");
        public int indexcount = 0;
        public List<string> headerValues = new List<string>();

        public ActionResult Index()
        {
            dt.Columns.AddRange(new DataColumn[7] { new DataColumn("OrderID", typeof(long)),
            new DataColumn("CustomerID", typeof(string)),
            new DataColumn("Freight",typeof(double)),
            new DataColumn("EmployeeID",typeof(decimal)),
            new DataColumn("OrderDate",typeof(DateTime)),
            new DataColumn("ShippedDate", typeof(DateTime)),
            new DataColumn("ShipCountry", typeof(string))
            });
            int code = 10000;
            for (int i = 1; i < 10; i++)
            {
                dt.Rows.Add(code + 1, "ALFKI", 2.3 * i, 1.1234, new DateTime(1991, 05, 15), new DateTime(1991, 05, 15), "India");
                dt.Rows.Add(code + 2, "ANATR", 3.3 * i, 2.2345, new DateTime(1990, 04, 04), new DateTime(1990, 04, 04), "America");
                dt.Rows.Add(code + 3, "ANTON", 4.3 * i, 3.3456, new DateTime(1957, 11, 30), new DateTime(1957, 11, 30), "London");
                dt.Rows.Add(code + 4, "BLONP", 5.3 * i, 4.4567, new DateTime(1930, 10, 22), new DateTime(1930, 10, 22), "Singapore");
                dt.Rows.Add(code + 5, "BOLID", 6.3 * i, 5.5678, new DateTime(1953, 02, 18), new DateTime(1953, 02, 18), "Malaysia");
                code += 5;
            }
            ViewBag.DataSource = dt;
            ViewBag.data = new int[] { 90, 180, 45, 135, 225, -90 };
            return View();
        }

        //[HttpPost]
        //[ValidateInput(false)]
        //public ActionResult FormValue(int games)
        //{
        //    ViewBag.selected = games;
        //    return View("Index");
        //}

        public ActionResult PdfExport(string gridModel)
        {
            GridPdfExport exp = new GridPdfExport();
            Grid gridProperty = ConvertGridObject(gridModel);
            gridProperty.ServerPdfHeaderQueryCellInfo = PdfHeaderQueryCellInfo;
            PdfGrid grid = new PdfGrid();
            PdfExportProperties pdfExportProperties = new PdfExportProperties();

            pdfExportProperties.IsRepeatHeader = true;

            pdfExportProperties.BeginCellLayout = new PdfGridBeginCellLayoutEventHandler(BeginCellEvent);
            gridProperty.ServerPdfQueryCellInfo = PdfQueryCellInfo;
            IEnumerable data = Utils.DataTableToJson(dt);

            var result = exp.PdfExport<dynamic>(gridProperty, data, pdfExportProperties);
            return result;
        }

        public ActionResult ExcelExport(string gridModel)
        {
            GridExcelExport exp = new GridExcelExport();
            Grid gridProperty = ConvertGridObject(gridModel);
            gridProperty.ServerExcelHeaderQueryCellInfo = ExcelHeaderQueryCellInfo;
            gridProperty.ServerExcelQueryCellInfo = ExcelQueryCellInfo;
            IEnumerable data = Utils.DataTableToJson(dt);
            var result = exp.ExcelExport<dynamic>(gridProperty, data);
            indexcount = 0;
            return result;
        }


        public void BeginCellEvent(object sender, PdfGridBeginCellLayoutEventArgs args)
        {
            PdfGrid grid = (PdfGrid)sender;
            var brush = new PdfSolidBrush(new PdfColor(Color.DimGray));
            args.Graphics.Save();
            args.Graphics.TranslateTransform(args.Bounds.X + 50, args.Bounds.Height + 40); // give the value for bounds x and Y by the user
            args.Graphics.RotateTransform(-60);   // give the rotate degree value by the user
                                                  // Draw the text at particular bounds.
            args.Graphics.DrawString(headerValues[args.CellIndex], new PdfStandardFont(PdfFontFamily.Helvetica, 10), brush, new PointF(0, 0));
            if (args.IsHeaderRow)
            {
                grid.Headers[0].Cells[args.CellIndex].Value = string.Empty;
            }
            args.Graphics.Restore();
        }

        private void PdfQueryCellInfo(object pdf)
        {
            ServerPdfQueryCellInfoEventArgs name = (ServerPdfQueryCellInfoEventArgs)pdf;
            //if(name.Column.Field == "OrderID")
            //{
            //    var index = indexcount++;

            //}
        }

        private void PdfHeaderQueryCellInfo(object pdf)
        {

            ServerPdfHeaderQueryCellInfoEventArgs name = (ServerPdfHeaderQueryCellInfoEventArgs)pdf;
            PdfGrid grid = new PdfGrid();
            headerValues.Add(name.Column.HeaderText);
            var longestString = headerValues.Where(s => s.Length == headerValues.Max(m => m.Length)).
                                First();
            PdfFont font = new PdfStandardFont(PdfFontFamily.Helvetica, 6);
            SizeF size = font.MeasureString(longestString);
            name.Headers[0].Height = size.Width * 2;

        }

        private void ExcelQueryCellInfo(object excel)
        {
            ServerExcelQueryCellInfoEventArgs name = (ServerExcelQueryCellInfoEventArgs)excel;
            //if(name.Column.Field == "OrderID")
            //{
            //    var index = indexcount++;

            //}

        }

        private void ExcelHeaderQueryCellInfo(object excel)
        {
            ServerExcelHeaderQueryCellInfoEventArgs name = (ServerExcelHeaderQueryCellInfoEventArgs)excel;

            headerValues.Add(name.Column.HeaderText);
            var longestString = headerValues.Where(s => s.Length == headerValues.Max(m => m.Length)).First();


            GridExcelExport exp = new GridExcelExport();

            //Font font = new Font("Courier New", 10);
            //Image fakeImage = new Bitmap(1, 1);
            //Graphics graphics = Graphics.FromImage(fakeImage);
            //SizeF size = graphics.MeasureString(longestString, font);
            //name.Cell.CellStyle.Rotation = 90;
            //name.Cell.AutofitRows();
            var size = exp.ExcelTextSize(name.Style.Font.FontName, (float)name.Style.Font.Size, longestString);

            //Font fontStyle = new Font(name.Style.Font.FontName, (float)name.Style.Font.Size);
            //RectangleF rectF = new RectangleF((float)0f, (float)0f, (float)int.MaxValue, (float)int.MaxValue);
            //RectangleF size1 = (exp.WorkBook as ApplicationImpl).GetMeasuredRectangle(longestString, fontStyle, rectF);


            name.Cell.RowHeight = size.Width;
            exp.HeaderCellRotate(name, 45);

            name.Style.Borders.LineStyle = ExcelLineStyle.None;


            //name.Cell.ColumnWidth = size.Width * 2;
            //name.Column.Width = Math.Round(size.Width * 2).ToString();
            //name.Column.HeaderTextAlign = Syncfusion.EJ2.Grids.TextAlign.Left;
            //name.Style.Borders.Color = Syncfusion.XlsIO.ExcelKnownColors.Red;
            name.Style.VerticalAlignment = Syncfusion.XlsIO.ExcelVAlign.VAlignCenter;
            //if (name.Style.Rotation > 180)
            //{

            //}
            //if (name.Style.Rotation <= 90)
            //{
            //    name.Style.HorizontalAlignment = Syncfusion.XlsIO.ExcelHAlign.HAlignLeft;
            //}
            //else
            //{
            //    name.Style.HorizontalAlignment = Syncfusion.XlsIO.ExcelHAlign.HAlignRight;
            //}




        }

        private Grid ConvertGridObject(string gridProperty)
        {
            Grid GridModel = (Grid)Newtonsoft.Json.JsonConvert.DeserializeObject(gridProperty, typeof(Grid));
            GridColumnModel cols = (GridColumnModel)Newtonsoft.Json.JsonConvert.DeserializeObject(gridProperty, typeof(GridColumnModel));
            GridModel.Columns = cols.columns;
            return GridModel;
        }
    }
    public class Orders
    {
        public long OrderID { get; set; }
        public string CustomerID { get; set; }
        public decimal EmployeeID { get; set; }
        public double Freight { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime ShippedDate { get; set; }
        public string ShipCountry { get; set; }
    }
}

