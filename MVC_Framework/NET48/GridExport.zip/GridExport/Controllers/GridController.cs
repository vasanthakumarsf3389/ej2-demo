﻿using Syncfusion.EJ2.Base;
using System;
using System.Collections.Generic;
using GridExportMVC.Models;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Syncfusion.EJ2.Linq;
using System.Collections;
using System.Security.AccessControl;
using System.Linq.Expressions;

namespace GridExportMVC.Controllers
{
    public class GridController : Controller
    {
        // GET: Grid
        public ActionResult Index()
        {
            List<object> DataRange = new List<object>
            {
                //new { Text = "1,000 Rows 11 Columns", Value = "1000" },
                //new { Text = "10,000 Rows 11 Columns", Value = "10000" },
                new { Text = "1,00,000 Rows 11 Columns", Value = "100000" },
                new { Text = "5,00,000 Rows 11 Columns", Value = "500000" },
                new { Text = "6,00,000 Rows 11 Columns", Value = "600000" },
                new { Text = "15,00,000 Rows 11 Columns", Value = "1500000" }
            };
            ViewBag.Data = DataRange;
            return View();
        }
        public class ExtendedDataManagerRequest : DataManagerRequest
        {  //inherit the class to show NewName as property of DataManager
            public string dataCount { get; set; }
        }

        [Route("Grid/UrlDataSource")]
        public ActionResult UrlDataSource(ExtendedDataManagerRequest dm)
        {

            IQueryable<TradeDetails> DataSource;
            //IEnumerable<TradeDetails> DataSource;
            int count = 0;
            int count1 = 0;
            // Overview drop down value change

            if (TradeDetails.tradeData.Count == 0)
            {
                TradeDetails.cacheDataCount = 100000;
                TradeDetails.GetAllRecords();
            }
            else if (int.TryParse(dm.dataCount, out int dataCount))
            {
                TradeDetails.cacheDataCount = dataCount;
            }

            //Queryable

            DataSource = TradeDetails.tradeData.Take(TradeDetails.cacheDataCount).AsQueryable();
            var operation = new QueryableOperation();

            // Enumerable

            //DataSource = TradeDetails.tradeData.Take(TradeDetails.cacheDataCount).AsEnumerable();
            //DataOperations operation = new DataOperations();

            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
                stopwatch.Stop();
                Debug.WriteLine("filter perform: " + stopwatch.ElapsedMilliseconds + "ms");
            }
            if (dm.Search != null && dm.Search.Count > 0)  //Search
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                DataSource = operation.PerformSearching(DataSource, dm.Search);
                stopwatch.Stop();
                Debug.WriteLine("search perform: " + stopwatch.ElapsedMilliseconds + "ms");
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
                stopwatch.Stop();
                Debug.WriteLine("sort perform: " + stopwatch.ElapsedMilliseconds + "ms");
            }
            
            if (dm.RequiresCounts)
            {
                
                //var sourceType = DataSource.ElementType;
                //Stopwatch stopwatch2 = new Stopwatch();
                //stopwatch2.Start();
                //foreach(var data in DataSource)
                //{
                //    count1++;
                //}
                //stopwatch2.Stop();
                //Debug.WriteLine("value: " + count1 + " count1 list perform: " + stopwatch2.ElapsedMilliseconds + "ms");


                Stopwatch stopwatch1 = new Stopwatch();
                stopwatch1.Start();
                count = DataSource.Cast<TradeDetails>().Count();
                stopwatch1.Stop();
                Debug.WriteLine("value: " + count + " count list perform: " + stopwatch1.ElapsedMilliseconds + "ms");


                //Stopwatch stopwatch2 = new Stopwatch();
                //stopwatch2.Start();
                //int count1 = DataSource.TryGetNonEnumeratedCount();
                //stopwatch2.Stop();
                //Debug.WriteLine("count1 array perform: " + stopwatch2.ElapsedMilliseconds + "ms");
            }

            // net 6, 7rc

            //if (TryGetNonEnumeratedCount<TradeDetails>(IEnumerable<TradeDetails>source, out int count2))
            //{

            //}

            if (dm.Skip != 0)
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                DataSource = operation.PerformSkip(DataSource, dm.Skip);//Paging
                stopwatch.Stop();
                Debug.WriteLine("skip perform: " + stopwatch.ElapsedMilliseconds + "ms");
            }
            if (dm.Take != 0)
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                DataSource = operation.PerformTake(DataSource, dm.Take);
                stopwatch.Stop();
                Debug.WriteLine("take perform: " + stopwatch.ElapsedMilliseconds + "ms");
            }
            Debug.WriteLine("------------------------------------------------------------------------------------------");
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }
    }
}