# MVC-EJ2-Grid-server-side-exporting
Exporting EJ2 ASP.NET MVC Grid in server side
